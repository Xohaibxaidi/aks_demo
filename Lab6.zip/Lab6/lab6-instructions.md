# Lab 6

## Scaling

The following lab illustrates how the Horizontal Pod Autoscaler works in Kubernetes

1. Create initial workload. Wait for deployments to complete.

kubectl apply -f complex-web-dep.yaml -f complex-web-svc.yaml

2. Create load workload. Wait for Current Metrics to increase in each pod.

kubectl apply -f complex-web-load.yaml

3. Increase load instances

kubectl scale --replicas=6 deploy/complex-web-load

4. Create Horizontal Pod Autoscaler. Wait for number of pods to stabilise.

kubectl apply -f complex-web-hpa.yaml

5. Decrease load instances. Wait for number of pods to decrease.

kubectl scale --replicas=1 deploy/complex-web-load

6. Delete load instances. Wait for number of pods to decrease down to 1.  Notice the orignal number of instances was 3.

kubectl delete deploy complex-web-load

7. Add another metric to HPA to show it can support more than one.

kubectl apply -f complex-web-hpa2.yaml

## Cleanup

kubectl delete svc complex-web-svc
kubectl delete deploy complex-web-dep
kubectl delete deploy complex-web-load
kubectl delete hpa complex-web-hpa-1
