# Lab 3

## Introduced scenario: a pod in CrashLoopBackOff

### Use describe + logs to identify cause

kubectl apply -f crashloop-pod-crash.yaml
kubectl get pod crashloop-pod -w
kubectl describe pod crashloop-pod
kubectl logs crashloop-pod
kubectl delete pod crashloop-pod

### Apply a fix (e.g., config change or restart pattern)

## Introduced scenario: Wrong image tag / image pull issue

### Identify via events and logs

kubectl apply -f failing-pod.yaml
kubectl get pods
kubectl logs nginx-pod --since 5m
kubectl describe pod nginx-pod

kubectl delete pod nginx-pod

### Practice safe restart/rollback

kubectl apply -f ng-dep.yaml
kubectl rollout status deployment/ng-dep
kubectl describe deployment ng-dep
kubectl set image deployment ng-dep nginx=k8slab/nginx:2
kubectl get pods
kubectl describe deployment ng-dep
kubectl rollout history deployment/ng-dep
kubectl rollout restart deployment/ng-dep
kubectl rollout status deployment/ng-dep
kubectl rollout undo deployment/ng-dep
kubectl delete deployment ng-dep