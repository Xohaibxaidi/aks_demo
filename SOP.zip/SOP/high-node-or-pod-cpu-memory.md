# Standard Operating Procedure: High Node or Pod CPU / Memory

| Field            | Value                                                |
| ---------------- | ---------------------------------------------------- |
| SOP ID           | SOP-K8S-002                                          |
| Title            | High Node or Pod CPU / Memory Remediation            |
| Version          | 1.0                                                  |
| Owner            | Platform / SRE Team                                  |
| Last Reviewed    | YYYY-MM-DD                                           |
| Next Review Due  | YYYY-MM-DD                                           |
| Severity / Sev   | Sev-3 (single workload, no user impact) / Sev-2 (degraded workload) / Sev-1 (cluster-wide saturation or customer-facing outage) |
| Approvers        | Platform Lead, Application Owner                     |

---

## 1. Purpose

This runbook provides a standardized, repeatable procedure for diagnosing and remediating sustained **high CPU or memory utilization** on Kubernetes nodes or Pods running on AKS. It is intended to minimize mean time to recovery (MTTR), prevent eviction storms and OOM kills, and produce consistent, evidence-based capacity decisions.

## 2. Scope

- Applies to all workloads running on AKS clusters owned by the Platform team.
- Covers Pods managed by Deployments, StatefulSets, DaemonSets, Jobs, and CronJobs.
- Covers node-level pressure on any node pool (system or user).
- Does **not** cover application logic crashes (see `pod-unhealthy-crashloopbackoff.md`) or full control-plane incidents — escalate those via the appropriate SOP.

## 3. Roles & Responsibilities

| Role                  | Responsibility                                                       |
| --------------------- | -------------------------------------------------------------------- |
| On-call Engineer      | First responder, executes triage and mitigation steps in this SOP.   |
| Application Owner     | Provides workload-specific context, validates restoration of service, approves resource changes. |
| Platform / SRE Lead   | Coordinates if incident is escalated to Sev-1 or exceeds SLA, approves node pool scaling. |
| Capacity / FinOps     | Reviews sustained capacity changes for cost impact.                  |
| Change Manager        | Approves any out-of-band scaling or hotfix deployment.               |

## 4. Prerequisites

- `kubectl` configured against the affected cluster (`kubectl config current-context`).
- `kubectl top` available (Metrics Server installed and healthy).
- Read access to the affected namespace; `exec` / `logs` permissions for deeper triage.
- Access to:
  - Azure portal / Azure Monitor / Container Insights for the cluster.
  - Log Analytics workspace for the cluster (KQL queries against `Perf`, `ContainerInventory`, `KubePodInventory`).
  - The cluster's HPA / KEDA / VPA / Cluster Autoscaler configuration.
  - Source repository and CI/CD pipeline for the affected workload.
- Incident ticket opened in the ITSM tool, with the workload name, namespace, cluster, and node pool recorded.

## 5. Symptom Definitions

A node or Pod is considered **saturated** if any of the following is true:

- A node reports `Conditions: MemoryPressure=True`, `DiskPressure=True`, or `PIDPressure=True`.
- A node's CPU utilization is greater than **85%** for more than 10 minutes (sustained).
- A node's working-set memory is greater than **85%** of allocatable for more than 10 minutes.
- A Pod is at or above **90%** of its CPU limit for more than 10 minutes (throttling) or **90%** of its memory limit (imminent OOM).
- `kubectl top` shows one Pod using a disproportionate share of node resources (>50% of a single node).
- Pods are being **Evicted** (`Reason: Evicted`, message `The node was low on resource`).
- Pods are repeatedly **OOMKilled** (`Reason: OOMKilled`, exit code `137`).
- HPA reports `ScalingLimited=True` with `reason: TooManyReplicas` or is stuck at `maxReplicas`.
- Alerts firing: `NodeCPUHigh`, `NodeMemoryHigh`, `PodCPUThrottling`, `PodMemoryNearLimit`.

## 6. Triage Workflow (High Level)

```
        ┌─────────────────────────────────┐
        │ Alert / report of high CPU or   │
        │ memory on node or pod           │
        └────────────────┬────────────────┘
                         │
                         ▼
                [1] Acknowledge alert
                         │
                         ▼
                [2] Identify scope
                         │
                         ▼
         [3] Collect diagnostics (top, describe, metrics, events)
                         │
                         ▼
         [4] Classify root cause category
                         │
        ┌────────────┬───┴────────┬────────────┬────────────┐
        ▼            ▼            ▼            ▼            ▼
   Noisy pod   Under-sized   Traffic spike  Memory leak  Node-pool
   / runaway    requests/    / load surge   / steady     under-
   workload    limits                       growth       provisioned
        │            │            │            │            │
        ▼            ▼            ▼            ▼            ▼
              [5] Apply mitigation (throttle / scale / right-size)
                         │
                         ▼
                [6] Verify recovery
                         │
                         ▼
                [7] Communicate & close
                         │
                         ▼
                [8] Post-incident review
```

## 7. Detailed Procedure

> Replace `<NAMESPACE>`, `<POD>`, `<DEPLOYMENT>`, `<CONTAINER>`, `<NODE>`, and `<NODEPOOL>` with the actual values for the affected workload.

### Step 1 — Acknowledge & Record

1. Acknowledge the alert in the monitoring system within the SLA (target: 5 minutes).
2. Open or update the incident ticket with:
   - Cluster name, node pool, namespace, workload name.
   - Alert timestamp and current utilization percentages.
   - Initial symptom (e.g. "node aks-userpool-12345-vmss000003 at 94% memory for 15 min, 4 pods Evicted").
3. Post a status message in the agreed incident channel (e.g. Teams / Slack).

### Step 2 — Identify Scope

Determine whether the saturation is on a single Pod, a single workload, a single node, or cluster-wide.

```powershell
# 2.1 Node-level utilization snapshot
kubectl top nodes

# 2.2 Pod-level utilization across the cluster, sorted hottest first
kubectl top pods -A --sort-by=cpu | Select-Object -First 20
kubectl top pods -A --sort-by=memory | Select-Object -First 20

# 2.3 Node conditions (look for MemoryPressure / DiskPressure / PIDPressure)
kubectl get nodes -o json | ConvertFrom-Json |
  ForEach-Object { $_.items } |
  Select-Object @{n='Name';e={$_.metadata.name}}, `
                @{n='Conditions';e={ ($_.status.conditions | Where-Object { $_.status -eq 'True' -and $_.type -ne 'Ready' }).type -join ',' }}
```

Decision:

- **One Pod hot, node healthy** → likely workload-local. Continue with this SOP, focus on the Pod.
- **All Pods of one workload hot** → likely under-sized / runaway code. Continue with this SOP.
- **One node hot, others fine** → noisy neighbor or skewed scheduling. Continue with this SOP.
- **Multiple nodes hot across a node pool** → likely under-provisioned pool or cluster-wide traffic. Continue, but engage Platform Lead early.

### Step 3 — Collect Diagnostics

Capture **before** making any changes. Attach output to the incident ticket.

```powershell
# 3.1 Hot pod summary and resource spec
kubectl get pod <POD> -n <NAMESPACE> -o wide
kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.containers[*].resources}'

# 3.2 Full describe (events, limits, last state, restart count, QoS class)
kubectl describe pod <POD> -n <NAMESPACE>

# 3.3 Current and previous container logs (look for GC pauses, slow queries, infinite loops)
kubectl logs <POD> -n <NAMESPACE> -c <CONTAINER> --tail=200
kubectl logs <POD> -n <NAMESPACE> -c <CONTAINER> --previous --tail=200

# 3.4 Namespace events, newest first (Evicted, OOMKilled, FailedScheduling)
kubectl get events -n <NAMESPACE> --sort-by=.lastTimestamp | Select-Object -Last 50

# 3.5 Hot node detail (allocatable vs allocated, pressure conditions, taints)
$node = kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.nodeName}'
kubectl describe node $node

# 3.6 Allocated vs allocatable summary for the node
kubectl describe node $node | Select-String -Pattern "Allocatable|Allocated resources" -Context 0,6

# 3.7 Owning workload spec (for rollback / right-sizing)
kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o yaml > deploy-snapshot.yaml

# 3.8 Autoscaler state
kubectl get hpa -A
kubectl describe hpa <HPA> -n <NAMESPACE>
kubectl get scaledobjects.keda.sh -A 2>$null

# 3.9 Cluster Autoscaler events (AKS)
kubectl -n kube-system logs -l app=cluster-autoscaler --tail=200 2>$null
```

Record key signals:

- QoS class (`Guaranteed`, `Burstable`, `BestEffort`) — `BestEffort` pods are evicted first.
- Current `requests` / `limits` per container and how close usage is to the limit.
- `Restart Count` and any `OOMKilled` history.
- Node conditions (`MemoryPressure`, `DiskPressure`, `PIDPressure`).
- HPA status: `CurrentReplicas`, `DesiredReplicas`, `currentMetricValue` vs `targetAverageValue`.
- Cluster Autoscaler messages such as `NotTriggerScaleUp` or quota errors.

### Step 4 — Classify the Root Cause

Use the table to map the strongest signal to a category and jump to the matching mitigation in Step 5.

| Signal (events / metrics / logs)                                                  | Likely category                  | Go to     |
| --------------------------------------------------------------------------------- | -------------------------------- | --------- |
| One Pod's CPU >> peers, sudden onset, no traffic change                           | Runaway / noisy workload         | 5.A       |
| Pod consistently at/above CPU limit, app logs show slow handlers, CPU throttling  | Under-sized CPU requests/limits  | 5.B       |
| `Reason: OOMKilled`, exit code `137`, memory climbs to limit then restarts        | Under-sized memory / leak        | 5.C       |
| HPA at `maxReplicas`, request rate elevated, latency normal-ish                   | Traffic spike / load surge       | 5.D       |
| Memory grows linearly over hours/days, never plateaus                             | Memory leak                      | 5.E       |
| Node `MemoryPressure=True`, multiple Pods `Evicted`                               | Node-level pressure              | 5.F       |
| Cluster Autoscaler shows `NotTriggerScaleUp` / quota / SKU exhaustion             | Node pool under-provisioned      | 5.G       |
| Hot Pods all scheduled to one node; other nodes idle                              | Scheduling / affinity imbalance  | 5.H       |
| `PIDPressure=True`, high process / thread count                                   | Fork bomb / thread leak          | 5.I       |
| DaemonSet (e.g. log agent) consuming high CPU/memory on every node                | Platform / DaemonSet misconfig   | 5.J       |

### Step 5 — Mitigation Playbooks

> Apply the **least disruptive** action first. Capture the command(s) run and the outcome in the ticket.
> **Do not change resource requests/limits in production without Application Owner approval**, except as a documented emergency mitigation that is back-ported to source control afterwards.

#### 5.A Runaway / Noisy Workload

1. Confirm the Pod is the top consumer:
   ```powershell
   kubectl top pods -A --sort-by=cpu | Select-Object -First 10
   ```
2. Inspect the application: recent deploy? a stuck request? a long-running job?
   ```powershell
   kubectl rollout history deploy/<DEPLOYMENT> -n <NAMESPACE>
   kubectl logs <POD> -n <NAMESPACE> -c <CONTAINER> --tail=200
   ```
3. If a recent deploy correlates with the spike, roll back:
   ```powershell
   kubectl rollout undo deploy/<DEPLOYMENT> -n <NAMESPACE>
   kubectl rollout status deploy/<DEPLOYMENT> -n <NAMESPACE>
   ```
4. If a single replica is stuck (hot loop / runaway thread), recycle it:
   ```powershell
   kubectl delete pod <POD> -n <NAMESPACE>
   ```
5. Notify the Application Owner; open a bug with logs and a CPU profile if possible.

#### 5.B Under-sized CPU Requests / Limits (Throttling)

1. Confirm throttling rather than true CPU starvation:
   - In Container Insights / Log Analytics, check `container_cpu_cfs_throttled_periods_total` vs `container_cpu_cfs_periods_total`.
   - In `kubectl top` the Pod sits at its limit and never above.
2. Check the current values:
   ```powershell
   kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o jsonpath='{.spec.template.spec.containers[*].resources}'
   ```
3. Short-term, with Application Owner approval, raise CPU limit by a controlled increment (e.g. +50%):
   ```powershell
   kubectl set resources deploy/<DEPLOYMENT> -n <NAMESPACE> --limits=cpu=<NEW_LIMIT>
   ```
4. Long-term: tune `requests` to typical usage and `limits` to peak; consider HPA on CPU and code-level optimization.

#### 5.C Under-sized Memory / OOMKilled

1. Confirm `Reason: OOMKilled` and exit code `137` in `kubectl describe`.
2. Check current limits:
   ```powershell
   kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o jsonpath='{.spec.template.spec.containers[*].resources}'
   ```
3. Short-term, with Application Owner approval, increase memory limit by a controlled increment (e.g. +50%):
   ```powershell
   kubectl set resources deploy/<DEPLOYMENT> -n <NAMESPACE> --limits=memory=<NEW_LIMIT>
   ```
4. Long-term: open a follow-up to investigate the memory profile (heap dump, GC tuning, VPA recommendation, true leak).
5. If repeated OOMs continue after a raise, escalate to category **5.E (Memory Leak)** rather than raising again.

#### 5.D Traffic Spike / Load Surge

1. Verify the spike is real by checking ingress / app metrics (RPS, queue depth).
2. Check HPA status:
   ```powershell
   kubectl get hpa <HPA> -n <NAMESPACE>
   kubectl describe hpa <HPA> -n <NAMESPACE>
   ```
3. If HPA is at `maxReplicas` and the load is legitimate, with approval raise the ceiling:
   ```powershell
   kubectl patch hpa <HPA> -n <NAMESPACE> -p '{"spec":{"maxReplicas":<NEW_MAX>}}'
   ```
4. If HPA is not configured for the saturated metric (e.g. memory-bound but only CPU-scaled), add the missing metric via the standard pipeline and back-port the change to source control.
5. If the surge is hostile (abuse / DDoS), engage Security Operations and apply rate limits at ingress / WAF, not at the Pod level.

#### 5.E Memory Leak (Steady Growth)

1. Confirm the pattern in Container Insights: memory climbs monotonically across restarts.
2. Capture a heap / memory snapshot before mitigation, if the runtime supports it (e.g. `jmap`, `dotnet-dump`, `pprof`).
3. Mitigate availability first by rolling the workload:
   ```powershell
   kubectl rollout restart deploy/<DEPLOYMENT> -n <NAMESPACE>
   ```
4. **Do not** chase the leak by raising memory limits indefinitely — file a bug, attach the snapshot, and treat further raises as exceptions.
5. Consider a temporary CronJob-based restart only as an explicit, approved workaround with an expiry date.

#### 5.F Node-Level Pressure / Evictions

1. Confirm node conditions and which Pods were evicted:
   ```powershell
   kubectl describe node $node | Select-String -Pattern "Pressure|Allocatable|Allocated"
   kubectl get pods -A --field-selector=status.phase=Failed -o wide | Select-String "Evicted"
   ```
2. Identify the top consumers on that node:
   ```powershell
   kubectl top pods -A --field-selector spec.nodeName=$node --sort-by=memory | Select-Object -First 10
   ```
3. If a single workload is dominating, treat as **5.A / 5.B / 5.C**.
4. If load is broadly distributed and the node is simply too small, cordon and drain it so the scheduler / Cluster Autoscaler can rebalance:
   ```powershell
   kubectl cordon $node
   kubectl drain $node --ignore-daemonsets --delete-emptydir-data --grace-period=120
   ```
5. Allow the Cluster Autoscaler to add capacity, or proceed to **5.G**.

#### 5.G Node Pool Under-Provisioned

1. Check Cluster Autoscaler events:
   ```powershell
   kubectl -n kube-system logs -l app=cluster-autoscaler --tail=200
   ```
2. Common causes: subscription / SKU quota exhaustion, region capacity, autoscaler `max-count` reached, taint mismatches.
3. With Platform Lead approval, scale the node pool manually:
   ```powershell
   az aks nodepool scale `
     --resource-group <RG> --cluster-name <CLUSTER> `
     --name <NODEPOOL> --node-count <NEW_COUNT>
   ```
4. If quota is the issue, open an Azure quota request; meanwhile shed non-critical workloads (scale down, pause CronJobs).
5. Back-port any sustained capacity increase into infrastructure-as-code (Bicep / Terraform).

#### 5.H Scheduling / Affinity Imbalance

1. Verify the imbalance:
   ```powershell
   kubectl get pods -A -o wide | Group-Object { ($_ -split '\s+')[7] } | Sort-Object Count -Descending | Select-Object -First 10
   ```
   *(Adjust the column index for your `kubectl` output.)*
2. Inspect `nodeAffinity`, `podAffinity`, `podAntiAffinity`, `topologySpreadConstraints`, and taints/tolerations on the hot workload.
3. If a `topologySpreadConstraint` is missing, add one (e.g. spread by `topology.kubernetes.io/zone` or `kubernetes.io/hostname`) via the standard pipeline.
4. As a one-off rebalance, delete a subset of replicas so they reschedule:
   ```powershell
   kubectl delete pod <POD> -n <NAMESPACE>
   ```

#### 5.I PID Pressure / Thread or Process Leak

1. Confirm `PIDPressure=True` on the node and identify the offending Pod (highest process count).
2. From the container, inspect process / thread count (`ps -eLf | wc -l`, `cat /proc/<pid>/status | grep Threads`).
3. Recycle the offending Pod to restore the node:
   ```powershell
   kubectl delete pod <POD> -n <NAMESPACE>
   ```
4. File a bug for the application owner; this is almost always an application defect (unbounded thread pool, fork-per-request, leaking goroutines).

#### 5.J Platform / DaemonSet Misconfiguration

1. If the high consumer is a platform component (log agent, metrics agent, service mesh sidecar, CSI driver), check its version, configuration, and recent change history.
2. Roll back the DaemonSet to the previous version using the standard platform pipeline.
3. Notify the platform component owner; do **not** locally edit a DaemonSet managed by GitOps without coordination.

### Step 6 — Verify Recovery

Recovery is confirmed when **all** of the following hold for at least 15 minutes:

- `kubectl top nodes` shows node CPU and memory below the configured alert thresholds (e.g. < 75%).
- `kubectl top pods -n <NAMESPACE>` shows the workload steady-state utilization within its requests and well below its limits.
- No new `Evicted`, `OOMKilled`, or `Unhealthy` events in the affected namespace.
- HPA `CurrentReplicas` ≤ `maxReplicas - 1` (i.e. headroom exists).
- Node conditions no longer report `MemoryPressure`, `DiskPressure`, or `PIDPressure`.
- Application-level health endpoint, latency, and key business KPIs are within normal bounds.
- Synthetic / smoke tests pass.

Record verification evidence (timestamps, `kubectl top` output, dashboard screenshots) in the ticket.

### Step 7 — Communicate & Close

1. Update the incident channel with the resolution summary:
   - What was saturated (node / pod / cluster).
   - Root cause category and the action that restored service.
   - Any residual risk, throttling, or follow-ups.
2. Close the incident in the ITSM tool with category and root-cause code populated.
3. Notify the Application Owner, Capacity / FinOps, and downstream stakeholders.

### Step 8 — Post-Incident Review

Required for Sev-1 and recommended for Sev-2:

- Schedule a blameless review within 5 business days.
- Capture timeline, contributing factors, and corrective actions.
- File backlog items for permanent fixes (e.g. right-size requests/limits, add HPA / VPA, tune GC, add `topologySpreadConstraints`, increase node pool `max-count`, raise quota).
- Update this SOP if a new failure mode or mitigation was discovered.

## 8. Escalation Matrix

| Condition                                                            | Escalate to             | Within  |
| -------------------------------------------------------------------- | ----------------------- | ------- |
| Recovery not achieved within 30 minutes                              | Platform / SRE Lead     | 30 min  |
| Customer-facing workload still degraded after 1 hour                 | Incident Manager (Sev-1)| 60 min  |
| Cluster Autoscaler cannot scale due to Azure quota / SKU             | Capacity / Cloud Ops    | 30 min  |
| Multiple node pools or whole cluster saturated                       | AKS Cluster Outage SOP  | Immediately |
| Suspected security incident (DDoS, crypto-miner workload)            | Security Operations     | Immediately |
| Repeated OOM / eviction loop after one mitigation attempt            | Application Owner + SRE Lead | 15 min |

## 9. Useful Reference Commands

```powershell
# Live top
kubectl top nodes
kubectl top pods -A --sort-by=cpu  | Select-Object -First 20
kubectl top pods -A --sort-by=memory | Select-Object -First 20

# Pods on a specific node, sorted by memory
kubectl top pods -A --field-selector spec.nodeName=<NODE> --sort-by=memory

# Evicted pods across the cluster
kubectl get pods -A --field-selector=status.phase=Failed -o wide | Select-String "Evicted"

# QoS class for a pod
kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.status.qosClass}{"\n"}'

# Node allocatable vs allocated
kubectl describe node <NODE> | Select-String -Pattern "Allocatable|Allocated resources" -Context 0,6

# HPA status
kubectl get hpa -A
kubectl describe hpa <HPA> -n <NAMESPACE>

# Cluster Autoscaler logs (AKS)
kubectl -n kube-system logs -l app=cluster-autoscaler --tail=200

# Scale a node pool manually
az aks nodepool scale --resource-group <RG> --cluster-name <CLUSTER> --name <NODEPOOL> --node-count <COUNT>

# Cordon / drain a hot node
kubectl cordon <NODE>
kubectl drain <NODE> --ignore-daemonsets --delete-emptydir-data --grace-period=120

# Quick KQL (Log Analytics) — top memory consumers, last hour
# Perf
# | where TimeGenerated > ago(1h)
# | where ObjectName == "K8SContainer" and CounterName == "memoryWorkingSetBytes"
# | summarize avg(CounterValue) by InstanceName
# | top 20 by avg_CounterValue desc
```

## 10. Related Documents

- Pod Unhealthy / CrashLoopBackOff SOP (`pod-unhealthy-crashloopbackoff.md`)
- AKS Cluster Outage SOP
- Deployment Rollback SOP
- HPA / KEDA / VPA Tuning Guide
- Cluster Autoscaler & Node Pool Capacity Guide
- Azure Quota Request Procedure
- Incident Management Policy

## 11. Revision History

| Version | Date       | Author | Change Summary           |
| ------- | ---------- | ------ | ------------------------ |
| 1.0     | YYYY-MM-DD | TBD    | Initial template version |
