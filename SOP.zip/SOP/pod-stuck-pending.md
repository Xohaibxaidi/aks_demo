# Standard Operating Procedure: Pod Stuck Pending

| Field            | Value                                                |
| ---------------- | ---------------------------------------------------- |
| SOP ID           | SOP-K8S-004                                          |
| Title            | Pod Stuck in `Pending` Phase Remediation             |
| Version          | 1.0                                                  |
| Owner            | Platform / SRE Team                                  |
| Last Reviewed    | YYYY-MM-DD                                           |
| Next Review Due  | YYYY-MM-DD                                           |
| Severity / Sev   | Sev-3 (single workload) / Sev-2 (multiple workloads) / Sev-1 (critical workload, customer impact) |
| Approvers        | Platform Lead, Application Owner                     |

---

## 1. Purpose

This runbook provides a standardized, repeatable procedure for diagnosing and remediating Kubernetes Pods that remain in the `Pending` phase and never reach `Running`. It is intended to minimize mean time to recovery (MTTR) and ensure consistent, evidence-based triage of scheduling, resource, image, storage, and admission-related failures.

## 2. Scope

- Applies to all workloads running on AKS clusters owned by the Platform team.
- Covers Pods created directly or managed by Deployments, StatefulSets, DaemonSets, Jobs, and CronJobs.
- Focuses on the period **before** a Pod's containers are started (scheduling, image pull setup, volume binding, admission).
- Does **not** cover Pods that have started and then crashed — use the **Pod Unhealthy / CrashLoopBackOff** SOP for those.
- Does **not** cover full cluster outages or control-plane incidents — escalate via the **AKS Cluster Outage** SOP.

## 3. Roles & Responsibilities

| Role                  | Responsibility                                                       |
| --------------------- | -------------------------------------------------------------------- |
| On-call Engineer      | First responder, executes triage and mitigation steps in this SOP.   |
| Application Owner     | Provides workload-specific context, validates restoration of service. |
| Platform / SRE Lead   | Coordinates if incident is escalated to Sev-1 or exceeds SLA.        |
| Capacity Manager      | Approves node pool scale-out or quota increases.                     |
| Change Manager        | Approves any out-of-band rollback / hotfix deployment.               |

## 4. Prerequisites

- `kubectl` configured against the affected cluster (`kubectl config current-context`).
- Read access to the affected namespace; cluster-level read for nodes, PVs, and events.
- Access to:
  - Azure portal / Azure Monitor / Container Insights for the cluster.
  - Log Analytics workspace for the cluster.
  - Container registry (ACR) used by the workload.
  - Source repository and CI/CD pipeline for the workload.
  - Subscription quota / capacity dashboards.
- Incident ticket opened in the ITSM tool, with the workload name, namespace, and cluster recorded.

## 5. Symptom Definitions

A Pod is considered **stuck Pending** if any of the following is true:

- `kubectl get pod` shows `STATUS: Pending` for more than 5 minutes.
- `kubectl describe pod` shows event `FailedScheduling` repeated over several minutes.
- `kubectl describe pod` shows `Reason: Unschedulable`, `Insufficient cpu`, `Insufficient memory`, `Insufficient pods`, `node(s) didn't match Pod's node affinity/selector`, `had untolerated taint`, or `had volume node affinity conflict`.
- Pod has containers in `Waiting` state with reason `ContainerCreating` for more than 5 minutes due to volume, network, or image setup.
- Deployment `availableReplicas` is less than `desiredReplicas` and the missing replicas are all in `Pending`.

## 6. Triage Workflow (High Level)

```
        ┌─────────────────────────────┐
        │ Alert / report of pod stuck │
        │ in Pending phase            │
        └──────────────┬──────────────┘
                       │
                       ▼
              [1] Acknowledge alert
                       │
                       ▼
              [2] Identify scope
                       │
                       ▼
         [3] Collect diagnostics (describe, events, nodes)
                       │
                       ▼
         [4] Classify root cause category
                       │
        ┌──────────┬───┴────┬──────────┬──────────┬──────────┐
        ▼          ▼        ▼          ▼          ▼          ▼
   Insufficient  Affinity / Taints   PVC /      Image /    Quota /
   resources    NodeSelector        Volume    Pull setup  Admission
        │          │        │          │          │          │
        └──────────┴────┬───┴──────────┴──────────┴──────────┘
                       ▼
              [5] Apply mitigation (scale / fix / rebind)
                       │
                       ▼
              [6] Verify recovery
                       │
                       ▼
              [7] Communicate & close
                       │
                       ▼
              [8] Post-incident review
```

## 7. Detailed Procedure

> Replace `<NAMESPACE>`, `<POD>`, `<DEPLOYMENT>`, `<PVC>`, and `<NODE>` with the actual values for the affected workload.

### Step 1 — Acknowledge & Record

1. Acknowledge the alert in the monitoring system within the SLA (target: 5 minutes).
2. Open or update the incident ticket with:
   - Cluster name, namespace, workload name.
   - Alert timestamp.
   - Initial symptom (e.g. "5/5 pods in Pending for 12 minutes").
3. Post a status message in the agreed incident channel (e.g. Teams / Slack).

### Step 2 — Identify Scope

Determine whether this affects a single Pod, a single workload, or many workloads across the cluster.

```powershell
# Cluster-wide view of pending pods
kubectl get pods -A --field-selector=status.phase=Pending

# Affected workload
kubectl get pods -n <NAMESPACE> -o wide
kubectl get deploy,sts,ds -n <NAMESPACE>

# Node capacity at a glance
kubectl get nodes -o wide
kubectl top nodes
```

Decision:

- **One pod pending, others scheduled** → likely affinity / taint / node-specific resource shortage. Continue with this SOP.
- **All pods of one workload pending** → likely spec problem (resources, selectors, PVC, image pull secret, admission). Continue with this SOP.
- **Pending pods across multiple namespaces / workloads** → suspect cluster-level capacity, autoscaler, quota, or admission webhook issue. Continue with this SOP and pre-notify Platform / SRE Lead.

### Step 3 — Collect Diagnostics

Capture **before** making any changes. Attach output to the incident ticket.

```powershell
# 3.1 Pod summary
kubectl get pod <POD> -n <NAMESPACE> -o wide

# 3.2 Full describe (scheduler events, conditions, volumes)
kubectl describe pod <POD> -n <NAMESPACE>

# 3.3 Namespace events, newest first
kubectl get events -n <NAMESPACE> --sort-by=.lastTimestamp | Select-Object -Last 50

# 3.4 Owning workload spec
kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o yaml > deploy-snapshot.yaml

# 3.5 Cluster capacity & node conditions
kubectl get nodes -o wide
kubectl describe nodes | Select-String -Pattern "Name:|Taints:|Allocatable:|Allocated resources:"

# 3.6 Resource quotas / limit ranges in the namespace
kubectl get resourcequota,limitrange -n <NAMESPACE>
kubectl describe resourcequota -n <NAMESPACE>

# 3.7 PVCs referenced by the pod
kubectl get pvc -n <NAMESPACE>
kubectl describe pvc <PVC> -n <NAMESPACE>

# 3.8 Cluster autoscaler status (if enabled)
kubectl -n kube-system logs deploy/cluster-autoscaler --tail=200
```

Record key signals from the **Events** section of `kubectl describe pod`:

- `FailedScheduling` with `Insufficient cpu`, `Insufficient memory`, or `Insufficient pods`.
- `node(s) didn't match Pod's node affinity/selector`.
- `had untolerated taint {key=value:effect}`.
- `had volume node affinity conflict`.
- `pod has unbound immediate PersistentVolumeClaims`.
- `FailedCreate` from a ReplicaSet referencing quota (`exceeded quota`).
- `Error creating: admission webhook ... denied the request`.
- `Failed to pull image` / `ErrImagePull` / `ImagePullBackOff` (still counted as Pending until first container starts).

### Step 4 — Classify the Root Cause

Use the table to map the strongest signal to a category and jump to the matching mitigation in Step 5.

| Signal (events / describe output)                                                    | Likely category                  | Go to |
| ------------------------------------------------------------------------------------ | -------------------------------- | ----- |
| `Insufficient cpu` / `Insufficient memory` / `Insufficient pods`                     | Cluster / node capacity          | 5.A   |
| `node(s) didn't match Pod's node affinity/selector`                                  | Node selector / affinity mismatch| 5.B   |
| `had untolerated taint`                                                              | Taint without matching toleration| 5.C   |
| `pod has unbound immediate PersistentVolumeClaims` / `had volume node affinity conflict` | Storage / PVC binding         | 5.D   |
| `Failed to pull image`, `ErrImagePull`, `ImagePullBackOff` during initial create     | Image pull / registry            | 5.E   |
| `exceeded quota` on ReplicaSet `FailedCreate`                                        | Namespace ResourceQuota          | 5.F   |
| `admission webhook ... denied the request` / `OPA` / `Gatekeeper` / `Kyverno` error  | Admission / policy denial        | 5.G   |
| `0/N nodes are available` with no other reason, autoscaler not scaling               | Cluster Autoscaler / node pool   | 5.H   |
| `Waiting: ContainerCreating` with CNI / IP allocation errors in events               | Networking / IPAM                | 5.I   |
| Pod requests exceed any single node's allocatable                                    | Unschedulable due to pod size    | 5.J   |

### Step 5 — Mitigation Playbooks

> Apply the **least disruptive** action first. Capture the command(s) run and the outcome in the ticket.

#### 5.A Cluster / Node Capacity Shortage

1. Confirm the shortage from `kubectl describe pod` events (e.g. `0/6 nodes are available: 6 Insufficient memory`).
2. Inspect current allocation vs allocatable:
   ```powershell
   kubectl describe nodes | Select-String -Pattern "Name:|Allocatable:|Allocated resources:" -Context 0,4
   kubectl top nodes
   ```
3. Options, in order of preference:
   - **Free capacity**: scale down non-critical workloads with Application Owner approval.
   - **Scale the node pool** (preferred for sustained shortage):
     ```powershell
     az aks nodepool scale `
       --resource-group <RG> --cluster-name <CLUSTER> `
       --name <NODEPOOL> --node-count <NEW_COUNT>
     ```
   - **Right-size the workload**: reduce `requests` only with Application Owner approval.
4. Verify the pod is scheduled after capacity becomes available.

#### 5.B Node Selector / Affinity Mismatch

1. Inspect `nodeSelector`, `affinity`, and `nodeName` in the Pod spec:
   ```powershell
   kubectl get pod <POD> -n <NAMESPACE> -o yaml | Select-String -Pattern "nodeSelector|affinity|nodeName" -Context 0,10
   ```
2. List node labels:
   ```powershell
   kubectl get nodes --show-labels
   ```
3. Determine whether the required label is missing, or the selector is wrong.
4. **Preferred fix**: correct the workload manifest in source control and redeploy via the standard pipeline.
5. **Emergency fix only**: label an existing node to match (and back-port to source control immediately):
   ```powershell
   kubectl label node <NODE> <KEY>=<VALUE>
   ```

#### 5.C Untolerated Taint

1. Identify the taint from the event (e.g. `had untolerated taint {workload=gpu:NoSchedule}`).
2. List node taints:
   ```powershell
   kubectl describe nodes | Select-String -Pattern "Name:|Taints:" -Context 0,1
   ```
3. **Preferred fix**: add the matching `toleration` to the Pod spec via source control and redeploy.
4. **Emergency only**: remove a stale taint from a node (only if intentionally placed and no longer required):
   ```powershell
   kubectl taint node <NODE> <KEY>=<VALUE>:<EFFECT>-
   ```
5. Do **not** remove taints applied by AKS system components (e.g. `kubernetes.azure.com/scalesetpriority=spot:NoSchedule`).

#### 5.D Storage / PVC Binding

1. Inspect the PVC and underlying PV:
   ```powershell
   kubectl get pvc -n <NAMESPACE>
   kubectl describe pvc <PVC> -n <NAMESPACE>
   kubectl get pv
   ```
2. Common sub-causes and actions:
   - **`pending` PVC, no PV**: verify the `StorageClass` exists and the provisioner is healthy:
     ```powershell
     kubectl get storageclass
     kubectl -n kube-system get pods | Select-String -Pattern "csi|azuredisk|azurefile"
     ```
   - **`volume node affinity conflict`**: the PV is zoned to a different availability zone than any available node. Recreate the workload in the matching zone or recreate the PVC against a zone-flexible `StorageClass`.
   - **`waitForFirstConsumer`**: confirm the Pod can be scheduled on at least one node (resolve 5.A / 5.B first).
3. For Azure Disk / Azure File issues, validate the underlying resource in the portal and engage the Storage owner if disk-level problems are suspected.

#### 5.E Image Pull / Registry

1. Inspect the image reference and pull secret:
   ```powershell
   kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.containers[*].image}'
   kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.imagePullSecrets[*].name}'
   ```
2. Validate the tag exists in ACR:
   ```powershell
   az acr repository show-tags --name <ACR_NAME> --repository <REPO> --output table
   ```
3. Check ACR pull permissions for the cluster's kubelet identity (`AcrPull` role) or the pull secret in the namespace.
4. If the tag is missing or corrupt, roll forward to a known-good tag and trigger an ACR re-push from the pipeline. Do **not** hand-edit images on the cluster as a permanent fix.

#### 5.F Namespace ResourceQuota / LimitRange

1. Confirm `FailedCreate` from the ReplicaSet references `exceeded quota`:
   ```powershell
   kubectl describe rs -n <NAMESPACE> | Select-String -Pattern "exceeded quota" -Context 0,2
   ```
2. Inspect current quota usage:
   ```powershell
   kubectl describe resourcequota -n <NAMESPACE>
   kubectl describe limitrange -n <NAMESPACE>
   ```
3. Options:
   - Reduce the workload's `requests` / replica count to fit within quota (with Application Owner approval).
   - Request a quota increase via the standard capacity / change process; update the quota object via GitOps.
4. Verify the new Pod is admitted and scheduled.

#### 5.G Admission / Policy Denial

1. Inspect the event for the webhook name and message (Gatekeeper, Kyverno, custom webhook).
2. Retrieve the relevant constraint or policy:
   ```powershell
   kubectl get constraints -A           # Gatekeeper
   kubectl get clusterpolicy,policy -A  # Kyverno
   kubectl get validatingwebhookconfiguration,mutatingwebhookconfiguration
   ```
3. Confirm whether the workload manifest is genuinely non-compliant (preferred fix: correct the manifest in source control), or whether the webhook itself is failing (engage policy owner).
4. Do **not** disable admission policies as a workaround without Change Manager approval.

#### 5.H Cluster Autoscaler / Node Pool

1. Confirm autoscaler is enabled and check recent activity:
   ```powershell
   az aks nodepool show --resource-group <RG> --cluster-name <CLUSTER> --name <NODEPOOL> `
     --query "{min:minCount,max:maxCount,current:count,autoscale:enableAutoScaling}"
   kubectl -n kube-system logs deploy/cluster-autoscaler --tail=200 | Select-String -Pattern "scale-up|noScaleUp|expand"
   ```
2. Common findings and actions:
   - **`noScaleUp` due to `max-nodes-total`**: raise the max node count for the pool.
   - **VM SKU quota exhausted in the region**: file a quota increase or scale a different node pool / SKU.
   - **Pods don't fit any pool template** (taints / labels / sizes): create or adjust a node pool whose template matches the workload.
3. After remediation, watch for new nodes joining and pods scheduling:
   ```powershell
   kubectl get nodes -w
   kubectl get pods -n <NAMESPACE> -w
   ```

#### 5.I Networking / IPAM (`ContainerCreating`)

1. If pods stay in `ContainerCreating` with CNI errors (e.g. `failed to allocate for range`, `no IP addresses available`), inspect the CNI configuration and subnet usage:
   ```powershell
   kubectl describe pod <POD> -n <NAMESPACE> | Select-String -Pattern "network|cni|sandbox" -Context 0,2
   ```
2. For Azure CNI, validate available IPs in the pod subnet via the Azure portal / `az network vnet subnet show`.
3. If the subnet is exhausted, free IPs by removing stale resources or migrate the node pool to a larger subnet (planned change).
4. Engage the Networking owner if NSG or route table changes are required.

#### 5.J Pod Larger Than Any Node

1. Compare the Pod's `requests` to the largest node's allocatable:
   ```powershell
   kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.containers[*].resources.requests}'
   kubectl describe nodes | Select-String -Pattern "Name:|Allocatable:" -Context 0,4
   ```
2. If requests exceed every node's allocatable, options are:
   - Reduce the Pod's `requests` (Application Owner approval).
   - Add a node pool with a larger VM SKU and route the workload there via `nodeSelector` / `tolerations`.
3. Verify scheduling succeeds after the change.

### Step 6 — Verify Recovery

Recovery is confirmed when **all** of the following hold for at least 10 minutes:

- `kubectl get pod -n <NAMESPACE>` shows the workload `Running` and `READY` (e.g. `1/1`), with no further `Pending` pods for the same workload.
- No new `FailedScheduling` events for the workload in `kubectl get events`.
- `kubectl rollout status deploy/<DEPLOYMENT> -n <NAMESPACE>` reports success.
- Application-level health endpoint and key business KPIs are within normal bounds.
- Synthetic / smoke tests pass.

Record verification evidence (timestamps and outputs) in the ticket.

### Step 7 — Communicate & Close

1. Update the incident channel with the resolution summary:
   - What was wrong.
   - What action restored service.
   - Any residual risk or follow-ups (e.g. permanent quota increase, manifest fix in PR).
2. Close the incident in the ITSM tool with category and root-cause code populated.
3. Notify the Application Owner and downstream stakeholders.

### Step 8 — Post-Incident Review

Required for Sev-1 and recommended for Sev-2:

- Schedule a blameless review within 5 business days.
- Capture timeline, contributing factors, and corrective actions.
- File backlog items for permanent fixes (e.g. right-size requests, raise autoscaler max, fix StorageClass zoning, update admission policy, expand pod subnet).
- Update this SOP if a new failure mode or mitigation was discovered.

## 8. Escalation Matrix

| Condition                                                            | Escalate to              | Within  |
| -------------------------------------------------------------------- | ------------------------ | ------- |
| Recovery not achieved within 30 minutes                              | Platform / SRE Lead      | 30 min  |
| Customer-facing workload still down after 1 hour                     | Incident Manager (Sev-1) | 60 min  |
| VM SKU quota / regional capacity blocks scale-out                    | Capacity Manager + Azure Support | Immediately |
| Admission webhook outage blocking all new pods cluster-wide          | Policy Owner + Platform Lead | Immediately |
| Suspected control-plane / cluster-wide failure                       | AKS Cluster Outage SOP   | Immediately |
| Suspected security incident (e.g. denied by security policy for a reason indicating compromise) | Security Operations      | Immediately |

## 9. Useful Reference Commands

```powershell
# Watch pending pods in real time
kubectl get pods -A --field-selector=status.phase=Pending -w

# Show the scheduler's reasoning for a single pod
kubectl describe pod <POD> -n <NAMESPACE> | Select-String -Pattern "Events:" -Context 0,40

# Sum of requests vs allocatable per node
kubectl describe nodes | Select-String -Pattern "Name:|Allocatable:|Allocated resources:" -Context 0,5

# All events of type Warning, newest first
kubectl get events -A --field-selector=type=Warning --sort-by=.lastTimestamp | Select-Object -Last 50

# Pending PVCs cluster-wide
kubectl get pvc -A | Select-String -Pattern "Pending"

# Cluster autoscaler decisions
kubectl -n kube-system logs deploy/cluster-autoscaler --tail=200 | Select-String -Pattern "scale-up|noScaleUp|expand|Final scale-up"

# AKS node pool capacity & autoscale settings
az aks nodepool list --resource-group <RG> --cluster-name <CLUSTER> -o table
```

## 10. Related Documents

- Pod Unhealthy / CrashLoopBackOff SOP
- AKS Cluster Outage SOP
- Deployment Rollback SOP
- Storage / PVC Recovery SOP
- Cluster Autoscaler & Node Pool Management SOP
- Admission Policy (Gatekeeper / Kyverno) SOP
- Incident Management Policy

## 11. Revision History

| Version | Date       | Author | Change Summary           |
| ------- | ---------- | ------ | ------------------------ |
| 1.0     | YYYY-MM-DD | TBD    | Initial template version |
