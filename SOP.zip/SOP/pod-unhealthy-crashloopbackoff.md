# Standard Operating Procedure: Pod Unhealthy / CrashLoopBackOff

| Field            | Value                                                |
| ---------------- | ---------------------------------------------------- |
| SOP ID           | SOP-K8S-001                                          |
| Title            | Pod Unhealthy / CrashLoopBackOff Remediation         |
| Version          | 1.0                                                  |
| Owner            | Platform / SRE Team                                  |
| Last Reviewed    | YYYY-MM-DD                                           |
| Next Review Due  | YYYY-MM-DD                                           |
| Severity / Sev   | Sev-2 (single workload) / Sev-1 (critical workload)  |
| Approvers        | Platform Lead, Application Owner                     |

---

## 1. Purpose

This runbook provides a standardized, repeatable procedure for diagnosing and remediating Kubernetes Pods that are reporting an unhealthy state, in particular Pods that are stuck in `CrashLoopBackOff`. It is intended to minimize mean time to recovery (MTTR) and ensure consistent, evidence-based troubleshooting.

## 2. Scope

- Applies to all workloads running on AKS clusters owned by the Platform team.
- Covers Pods managed by Deployments, StatefulSets, DaemonSets, Jobs, and CronJobs.
- Does **not** cover full cluster outages, node-level failures across many nodes, or control-plane incidents — escalate those via the Cluster Outage SOP.

## 3. Roles & Responsibilities

| Role                  | Responsibility                                                       |
| --------------------- | -------------------------------------------------------------------- |
| On-call Engineer      | First responder, executes triage and mitigation steps in this SOP.   |
| Application Owner     | Provides workload-specific context, validates restoration of service. |
| Platform / SRE Lead   | Coordinates if incident is escalated to Sev-1 or exceeds SLA.        |
| Change Manager        | Approves any out-of-band rollback / hotfix deployment.               |

## 4. Prerequisites

- `kubectl` configured against the affected cluster (`kubectl config current-context`).
- Read access to the affected namespace; `exec` / `logs` permissions for deeper triage.
- Access to:
  - Azure portal / Azure Monitor / Container Insights for the cluster.
  - Log Analytics workspace for the cluster.
  - Container registry (ACR) used by the workload.
  - Source repository and CI/CD pipeline for the workload.
- Incident ticket opened in the ITSM tool, with the workload name, namespace, and cluster recorded.

## 5. Symptom Definitions

A Pod is considered **unhealthy** if any of the following is true:

- `kubectl get pod` shows status `CrashLoopBackOff`, `Error`, `ImagePullBackOff`, `ErrImagePull`, `CreateContainerConfigError`, or `OOMKilled`.
- Pod has been in `Pending` for more than 5 minutes.
- Pod `READY` column shows `0/N` where `N > 0` for more than 5 minutes.
- Liveness or readiness probe failures are repeatedly logged in events.
- Deployment `availableReplicas` is less than `desiredReplicas` for more than 5 minutes.

## 6. Triage Workflow (High Level)

```
        ┌─────────────────────────────┐
        │ Alert / report of unhealthy │
        │ pod or CrashLoopBackOff     │
        └──────────────┬──────────────┘
                       │
                       ▼
              [1] Acknowledge alert
                       │
                       ▼
              [2] Identify scope
                       │
                       ▼
         [3] Collect diagnostics (logs, events, describe)
                       │
                       ▼
         [4] Classify root cause category
                       │
        ┌──────────────┼────────────────┬──────────────┐
        ▼              ▼                ▼              ▼
   App crash     Config / Secret    Image / Pull   Resource / Node
        │              │                │              │
        ▼              ▼                ▼              ▼
              [5] Apply mitigation (rollback / fix / scale)
                       │
                       ▼
              [6] Verify recovery
                       │
                       ▼
              [7] Communicate & close
                       │
                       ▼
              [8] Post-incident review
```

## 7. Detailed Procedure

> Replace `<NAMESPACE>`, `<POD>`, `<DEPLOYMENT>`, and `<CONTAINER>` with the actual values for the affected workload.

### Step 1 — Acknowledge & Record

1. Acknowledge the alert in the monitoring system within the SLA (target: 5 minutes).
2. Open or update the incident ticket with:
   - Cluster name, namespace, workload name.
   - Alert timestamp.
   - Initial symptom (e.g. "3/5 pods in CrashLoopBackOff").
3. Post a status message in the agreed incident channel (e.g. Teams / Slack).

### Step 2 — Identify Scope

Determine whether this is a single Pod, a single workload, or cluster-wide.

```powershell
# Cluster-wide view of unhealthy pods
kubectl get pods -A --field-selector=status.phase!=Running,status.phase!=Succeeded

# Affected workload
kubectl get pods -n <NAMESPACE> -o wide
kubectl get deploy,sts,ds -n <NAMESPACE>
```

Decision:

- **One pod, others healthy** → likely node-local or transient. Continue with this SOP.
- **All pods of one workload unhealthy** → likely config / image / code issue. Continue with this SOP.
- **Multiple workloads across namespaces** → suspect node / cluster issue. Escalate to Cluster Outage SOP, but still capture diagnostics below.

### Step 3 — Collect Diagnostics

Capture **before** making any changes. Attach output to the incident ticket.

```powershell
# 3.1 Pod summary
kubectl get pod <POD> -n <NAMESPACE> -o wide

# 3.2 Full describe (events, probes, last state, exit code, restart count)
kubectl describe pod <POD> -n <NAMESPACE>

# 3.3 Current container logs
kubectl logs <POD> -n <NAMESPACE> -c <CONTAINER> --tail=200

# 3.4 Previous container logs (key for CrashLoopBackOff)
kubectl logs <POD> -n <NAMESPACE> -c <CONTAINER> --previous --tail=200

# 3.5 Namespace events, newest first
kubectl get events -n <NAMESPACE> --sort-by=.lastTimestamp | Select-Object -Last 50

# 3.6 Owning workload spec
kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o yaml > deploy-snapshot.yaml

# 3.7 Node health for the pod's node
$node = kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.nodeName}'
kubectl describe node $node
```

Record key signals:

- `Last State` (`Terminated` / `Waiting`) and `Reason` (`Error`, `OOMKilled`, `CrashLoopBackOff`, `ContainerCannotRun`).
- `Exit Code` (e.g. `137` = OOM / SIGKILL, `139` = segfault, `1` / `2` = app error).
- `Restart Count` and `Age`.
- Events such as `Failed`, `BackOff`, `Unhealthy`, `FailedScheduling`, `FailedMount`, `ErrImagePull`.

### Step 4 — Classify the Root Cause

Use the table to map the strongest signal to a category and jump to the matching mitigation in Step 5.

| Signal (events / status / exit code)                              | Likely category               | Go to     |
| ----------------------------------------------------------------- | ----------------------------- | --------- |
| Exit code `0` or `1` with app stack trace in logs                 | Application error             | 5.A       |
| Exit code `137`, `Reason: OOMKilled`                              | Memory limit / leak           | 5.B       |
| `Liveness probe failed` / `Readiness probe failed` events         | Probe misconfiguration / slow start | 5.C   |
| `CreateContainerConfigError`, `secret/configmap not found`        | Missing config / secret       | 5.D       |
| `ErrImagePull`, `ImagePullBackOff`, `manifest unknown`            | Image / registry issue        | 5.E       |
| `FailedScheduling`, `Insufficient cpu/memory`                     | Resource / scheduling         | 5.F       |
| `FailedMount`, `VolumeAttach` errors                              | Storage / volume              | 5.G       |
| Network errors in logs, DNS failures, `connection refused` to deps | Dependency / network         | 5.H       |
| Multiple pods on same node failing similarly                      | Node-level issue              | 5.I       |

### Step 5 — Mitigation Playbooks

> Apply the **least disruptive** action first. Capture the command(s) run and the outcome in the ticket.

#### 5.A Application Error (crash in code)

1. Confirm the failure is reproducible by reviewing `--previous` logs across at least two restarts.
2. Identify the last successful image tag:
   ```powershell
   kubectl rollout history deploy/<DEPLOYMENT> -n <NAMESPACE>
   ```
3. Roll back to the last known good revision:
   ```powershell
   kubectl rollout undo deploy/<DEPLOYMENT> -n <NAMESPACE>
   kubectl rollout status deploy/<DEPLOYMENT> -n <NAMESPACE>
   ```
4. Notify the Application Owner; open a bug with logs attached.

#### 5.B Memory Limit Exceeded / OOMKilled

1. Confirm `Reason: OOMKilled` and exit code `137` in `kubectl describe`.
2. Check current limits:
   ```powershell
   kubectl get deploy <DEPLOYMENT> -n <NAMESPACE> -o jsonpath='{.spec.template.spec.containers[*].resources}'
   ```
3. Short-term: increase memory limit by a controlled increment (e.g. +50%) **only with Application Owner approval**:
   ```powershell
   kubectl set resources deploy/<DEPLOYMENT> -n <NAMESPACE> --limits=memory=<NEW_LIMIT>
   ```
4. Long-term: open a follow-up to investigate memory profile (HPA, VPA, code leak).

#### 5.C Probe Misconfiguration / Slow Start

1. Review probe definitions in the Pod spec (`livenessProbe`, `readinessProbe`, `startupProbe`).
2. Check whether `initialDelaySeconds` is shorter than actual cold-start time observed in logs.
3. If app needs longer warm-up, prefer adding a `startupProbe` rather than disabling liveness.
4. Patch the Deployment with corrected probe values via the standard GitOps / pipeline flow. Use direct `kubectl edit` only as an emergency mitigation, then back-port to source control.

#### 5.D Missing Config / Secret

1. Identify the missing object from the event message, e.g. `secret "db-creds" not found`.
2. Confirm whether it exists in the namespace:
   ```powershell
   kubectl get secret,configmap -n <NAMESPACE>
   ```
3. If accidentally deleted, restore from Key Vault / source of truth (do **not** hand-craft secrets from memory).
4. If renamed in a recent deploy, roll back the workload (see 5.A) and reconcile naming in source control.

#### 5.E Image / Registry Issue

1. Inspect the image reference:
   ```powershell
   kubectl get pod <POD> -n <NAMESPACE> -o jsonpath='{.spec.containers[*].image}'
   ```
2. Validate the tag exists in ACR:
   ```powershell
   az acr repository show-tags --name <ACR_NAME> --repository <REPO> --output table
   ```
3. Check ACR pull permissions for the cluster's kubelet identity / pull secret.
4. If the tag is missing or corrupt, roll back to the previous good tag (5.A) and trigger an ACR re-push from the pipeline.

#### 5.F Resource / Scheduling Failure

1. Inspect the event for the resource shortage (`Insufficient cpu`, `Insufficient memory`, taint mismatches).
2. Verify node pool capacity:
   ```powershell
   kubectl top nodes
   kubectl describe nodes | Select-String -Pattern "Allocatable|Allocated"
   ```
3. Options, in order of preference:
   - Scale down non-critical workloads to free capacity.
   - Trigger cluster autoscaler / scale the node pool.
   - Reduce requests on the affected workload **only with owner approval**.
4. Verify scheduling succeeds after action.

#### 5.G Storage / Volume Issue

1. Inspect PVC and PV state:
   ```powershell
   kubectl get pvc -n <NAMESPACE>
   kubectl describe pvc <PVC> -n <NAMESPACE>
   ```
2. Check the underlying Azure disk / file share in the portal.
3. For `FailedAttach` after node failure, cordon the failed node and delete the Pod so it can be rescheduled and the volume reattached.
4. Engage the Storage owner if disk-level corruption is suspected.

#### 5.H Dependency / Network

1. Confirm the downstream dependency (database, API, queue) is healthy via its own dashboard.
2. From inside the cluster, validate DNS and connectivity:
   ```powershell
   kubectl run netcheck --rm -it --image=mcr.microsoft.com/azure-cli --restart=Never -- bash -c "nslookup <HOST>; curl -sv https://<HOST>"
   ```
3. Check NetworkPolicies, NSGs, and private endpoints if connectivity fails.

#### 5.I Node-Level Issue

1. Identify the node and check its conditions:
   ```powershell
   kubectl get node $node -o jsonpath='{.status.conditions}'
   ```
2. If `Ready=False` or `DiskPressure`/`MemoryPressure`/`PIDPressure`:
   - Cordon the node: `kubectl cordon $node`
   - Drain it: `kubectl drain $node --ignore-daemonsets --delete-emptydir-data`
   - Allow autoscaler / node auto-repair to replace it, or repair manually.

### Step 6 — Verify Recovery

Recovery is confirmed when **all** of the following hold for at least 10 minutes:

- `kubectl get pod -n <NAMESPACE>` shows the workload `Running` and `READY` (e.g. `1/1`).
- `Restart Count` is no longer increasing.
- Liveness / readiness probes are passing (no new `Unhealthy` events).
- Application-level health endpoint and key business KPIs are within normal bounds.
- Synthetic / smoke tests pass.

Record verification evidence (timestamps and outputs) in the ticket.

### Step 7 — Communicate & Close

1. Update the incident channel with the resolution summary:
   - What was wrong.
   - What action restored service.
   - Any residual risk or follow-ups.
2. Close the incident in the ITSM tool with category and root-cause code populated.
3. Notify the Application Owner and downstream stakeholders.

### Step 8 — Post-Incident Review

Required for Sev-1 and recommended for Sev-2:

- Schedule a blameless review within 5 business days.
- Capture timeline, contributing factors, and corrective actions.
- File backlog items for permanent fixes (e.g. add startup probe, fix memory leak, harden CI image scanning).
- Update this SOP if a new failure mode or mitigation was discovered.

## 8. Escalation Matrix

| Condition                                                            | Escalate to             | Within  |
| -------------------------------------------------------------------- | ----------------------- | ------- |
| Recovery not achieved within 30 minutes                              | Platform / SRE Lead     | 30 min  |
| Customer-facing workload still down after 1 hour                     | Incident Manager (Sev-1)| 60 min  |
| Suspected security incident (e.g. malicious image, secret leak)      | Security Operations     | Immediately |
| Suspected control-plane / cluster-wide failure                       | AKS Cluster Outage SOP  | Immediately |
| Data loss or corruption suspected                                    | Data Owner + DR runbook | Immediately |

## 9. Useful Reference Commands

```powershell
# Watch pod status in real time
kubectl get pods -n <NAMESPACE> -w

# Pods sorted by restart count
kubectl get pods -n <NAMESPACE> --sort-by=.status.containerStatuses[0].restartCount

# Top consumers
kubectl top pods -n <NAMESPACE>
kubectl top nodes

# Recent events across the cluster
kubectl get events -A --sort-by=.lastTimestamp | Select-Object -Last 50

# Exec into a sidecar (when the main container won't stay up)
kubectl exec -it <POD> -n <NAMESPACE> -c <SIDECAR> -- /bin/sh

# Force-recreate a pod (last resort, only for stateless workloads)
kubectl delete pod <POD> -n <NAMESPACE>
```

## 10. Related Documents

- AKS Cluster Outage SOP
- Deployment Rollback SOP
- Secrets and Key Vault SOP
- Storage / PVC Recovery SOP
- Incident Management Policy

## 11. Revision History

| Version | Date       | Author | Change Summary           |
| ------- | ---------- | ------ | ------------------------ |
| 1.0     | YYYY-MM-DD | TBD    | Initial template version |
