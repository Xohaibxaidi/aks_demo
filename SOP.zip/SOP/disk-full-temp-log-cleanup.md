# Standard Operating Procedure: Disk Full / Temp & Log Cleanup

| Field            | Value                                                |
| ---------------- | ---------------------------------------------------- |
| SOP ID           | SOP-K8S-003                                          |
| Title            | Disk Full / Temp & Log Cleanup Remediation           |
| Version          | 1.0                                                  |
| Owner            | Platform / SRE Team                                  |
| Last Reviewed    | YYYY-MM-DD                                           |
| Next Review Due  | YYYY-MM-DD                                           |
| Severity / Sev   | Sev-2 (single node) / Sev-1 (multiple nodes or etcd) |
| Approvers        | Platform Lead, Application Owner                     |

---

## 1. Purpose

This runbook provides a standardized, repeatable procedure for diagnosing and remediating disk-pressure conditions on Kubernetes nodes — in particular full or near-full root, container runtime, and log volumes — including safe cleanup of temporary files, rotated logs, unused container images, and ephemeral storage consumed by Pods. It is intended to minimize mean time to recovery (MTTR), prevent Pod evictions, and avoid data loss caused by aggressive cleanup.

## 2. Scope

- Applies to all AKS clusters and their worker node pools owned by the Platform team.
- Covers worker-node disk pressure: OS disk, kubelet root (`/var/lib/kubelet`), container runtime store (`/var/lib/containerd`), log directories (`/var/log`), and Pod ephemeral storage (`emptyDir`, container writable layer).
- Covers PersistentVolume (PVC) capacity exhaustion at a high level; deep storage-backend recovery is out of scope and is handled by the Storage / PVC Recovery SOP.
- Does **not** cover etcd / control-plane disk exhaustion on managed AKS (Microsoft-managed) — escalate via Azure support; for self-managed control planes, follow the dedicated etcd runbook.
- Does **not** cover full cluster outages — escalate via the Cluster Outage SOP.

## 3. Roles & Responsibilities

| Role                  | Responsibility                                                       |
| --------------------- | -------------------------------------------------------------------- |
| On-call Engineer      | First responder, executes triage and mitigation steps in this SOP.   |
| Application Owner     | Identifies safe-to-evict workloads, validates restoration of service. |
| Platform / SRE Lead   | Approves destructive cleanup on shared nodes; coordinates escalation. |
| Storage Owner         | Engaged when the issue is on a managed disk / file share (PVC).      |
| Change Manager        | Approves any out-of-band node pool resize or image purge at scale.   |

## 4. Prerequisites

- `kubectl` configured against the affected cluster (`kubectl config current-context`).
- Read access to all namespaces; `node-shell` / SSH or `kubectl debug node` permission for node-level triage.
- Access to:
  - Azure portal / Azure Monitor / Container Insights for the cluster.
  - Log Analytics workspace (tables: `KubeNodeInventory`, `Perf`, `ContainerLog`, `InsightsMetrics`).
  - Node pool configuration in AKS (OS disk type and size).
- Incident ticket opened in the ITSM tool, with the cluster, node pool, and node name recorded.

## 5. Symptom Definitions

A node or workload is considered to be under **disk pressure** if any of the following is true:

- `kubectl get nodes` shows a node `Condition: DiskPressure=True` or `Ready=False` with disk-related reason.
- Events such as `EvictionThresholdMet`, `NodeHasDiskPressure`, `FreeDiskSpaceFailed`, `ImageGCFailed`, `FailedCreatePodSandBox` are present.
- Pods on a node are evicted with reason `Evicted` and message `The node was low on resource: ephemeral-storage` or `imagefs`.
- Pods report `Reason: Evicted` with messages referencing `nodefs` or `imagefs` usage above threshold.
- Application errors such as `no space left on device`, `ENOSPC`, or write failures in container logs.
- A PVC-backed workload reports `disk full` despite the node being healthy (PV exhaustion, not node).
- Azure Monitor / Container Insights shows node `DiskUsedPercentage` above 85% sustained for 10+ minutes.

## 6. Triage Workflow (High Level)

```
        ┌─────────────────────────────┐
        │ Alert / report of disk full │
        │ or DiskPressure on a node   │
        └──────────────┬──────────────┘
                       │
                       ▼
              [1] Acknowledge alert
                       │
                       ▼
              [2] Identify scope (node vs PVC vs cluster)
                       │
                       ▼
         [3] Collect diagnostics (df, du, events, top)
                       │
                       ▼
         [4] Classify root cause category
                       │
        ┌──────────────┼────────────────┬──────────────┐
        ▼              ▼                ▼              ▼
   Log growth     Image bloat       Ephemeral /     PVC full
                                    emptyDir
        │              │                │              │
        ▼              ▼                ▼              ▼
              [5] Apply mitigation (rotate / prune / evict / expand)
                       │
                       ▼
              [6] Verify recovery
                       │
                       ▼
              [7] Communicate & close
                       │
                       ▼
              [8] Post-incident review
```

## 7. Detailed Procedure

> Replace `<NAMESPACE>`, `<POD>`, `<NODE>`, `<DEPLOYMENT>`, `<PVC>`, and `<CONTAINER>` with the actual values for the affected resources.

### Step 1 — Acknowledge & Record

1. Acknowledge the alert in the monitoring system within the SLA (target: 5 minutes).
2. Open or update the incident ticket with:
   - Cluster name, node pool, node name(s).
   - Alert timestamp and disk usage percentage at alert time.
   - Initial symptom (e.g. "Node aks-userpool-12345-vmss000003 reporting DiskPressure, 3 pods evicted").
3. Post a status message in the agreed incident channel (e.g. Teams / Slack).

### Step 2 — Identify Scope

Determine whether this is a single node, multiple nodes, or a PVC-level issue.

```powershell
# Nodes reporting any pressure condition
kubectl get nodes -o json |
  ConvertFrom-Json |
  Select-Object -ExpandProperty items |
  ForEach-Object {
    $n = $_.metadata.name
    $_.status.conditions |
      Where-Object { $_.type -in 'DiskPressure','MemoryPressure','PIDPressure','Ready' -and $_.status -ne 'False' } |
      ForEach-Object { "{0,-50} {1,-15} {2}" -f $n, $_.type, $_.status }
  }

# Recently evicted pods (cluster-wide)
kubectl get pods -A -o json |
  ConvertFrom-Json |
  Select-Object -ExpandProperty items |
  Where-Object { $_.status.reason -eq 'Evicted' } |
  Select-Object @{n='Namespace';e={$_.metadata.namespace}}, @{n='Pod';e={$_.metadata.name}}, @{n='Message';e={$_.status.message}}

# Disk-related events in the last hour
kubectl get events -A --field-selector type!=Normal --sort-by=.lastTimestamp |
  Select-String -Pattern 'Disk|Evict|ImageGC|nodefs|imagefs|ephemeral-storage|FreeDiskSpaceFailed'
```

Decision:

- **One node, others healthy** → likely log/image growth or a noisy Pod on that node. Continue with this SOP.
- **Multiple nodes in the same pool** → suspect baseline log/image volume or undersized OS disk. Continue with this SOP; consider node-pool-level remediation in Step 5.
- **Application reports `no space left` but node `DiskPressure=False`** → likely PVC full. Jump to **5.D**.
- **Many nodes across pools simultaneously** → suspect a daemon (logging agent, malware scanner) misbehaving cluster-wide. Continue with this SOP and engage the Platform Lead.

### Step 3 — Collect Diagnostics

Capture **before** making any changes. Attach output to the incident ticket.

```powershell
# 3.1 Node summary and conditions
kubectl describe node <NODE>

# 3.2 Allocatable vs allocated ephemeral storage on the node
kubectl describe node <NODE> | Select-String -Pattern 'ephemeral-storage|Allocatable|Allocated'

# 3.3 Pods on the node, sorted by ephemeral-storage usage where available
kubectl get pods --all-namespaces --field-selector spec.nodeName=<NODE> -o wide

# 3.4 Recent events on this node
kubectl get events -A --field-selector involvedObject.kind=Node,involvedObject.name=<NODE> --sort-by=.lastTimestamp

# 3.5 Open a privileged debug session on the node (preferred over SSH)
kubectl debug node/<NODE> -it --image=mcr.microsoft.com/cbl-mariner/busybox:2.0
# then, inside the debug pod (chroot to host fs is at /host):
#   chroot /host /bin/bash
#   df -hT
#   df -i
#   du -xh --max-depth=1 /var/log     2>/dev/null | sort -h | tail -20
#   du -xh --max-depth=1 /var/lib/containerd 2>/dev/null | sort -h | tail -20
#   du -xh --max-depth=1 /var/lib/kubelet/pods 2>/dev/null | sort -h | tail -20
#   journalctl --disk-usage
#   ls -lhS /var/log/*.log /var/log/*.gz 2>/dev/null | head -20
```

Record key signals:

- Filesystem(s) above 85% used (`/`, `/var`, `/var/lib/containerd`, `/var/lib/kubelet`, `/var/log`).
- Inode exhaustion (`df -i` shows `IUse% = 100%` even when `df -h` shows free space).
- Largest directories under `/var/log`, `/var/lib/containerd`, and `/var/lib/kubelet/pods/*/volumes/kubernetes.io~empty-dir`.
- Pods with high `ephemeral-storage` requests/limits, or with no limits set at all.
- Whether the container runtime image GC has fired (`ImageGCFailed` events).

### Step 4 — Classify the Root Cause

Use the table to map the strongest signal to a category and jump to the matching mitigation in Step 5.

| Signal (path / event / message)                                                                 | Likely category                  | Go to |
| ----------------------------------------------------------------------------------------------- | -------------------------------- | ----- |
| `/var/log` dominates usage; rotated `.log` / `.gz` files; `journalctl --disk-usage` very high   | OS / agent log growth            | 5.A   |
| `/var/lib/containerd` (or `/var/lib/docker`) dominates; many old images / dangling layers       | Container image bloat            | 5.B   |
| `/var/lib/kubelet/pods/*/volumes/kubernetes.io~empty-dir/...` large; Pod evictions on `nodefs`  | Pod ephemeral / emptyDir abuse   | 5.C   |
| Application reports `ENOSPC` but node `DiskPressure=False`; PVC near 100%                        | PVC / PV capacity exhaustion     | 5.D   |
| `df -i` shows 100% inode usage but `df -h` shows free bytes                                      | Inode exhaustion                 | 5.E   |
| `ImageGCFailed`, `FreeDiskSpaceFailed` events; runtime store on its own disk full                | Runtime / image GC misconfigured | 5.F   |
| Multiple nodes in pool consistently at 85%+ with no obvious offender                             | Node pool undersized             | 5.G   |
| Core dumps / heap dumps in `/var/lib/kubelet/pods/.../` or `/var/crash`                          | Crash artifacts                  | 5.H   |

### Step 5 — Mitigation Playbooks

> Apply the **least disruptive** action first. Prefer rotating / pruning over deleting. Never `rm -rf` inside `/var/lib/kubelet/pods/*` or `/var/lib/containerd/*` directly — let kubelet and the container runtime manage those paths. Capture each command run and the outcome in the ticket.

#### 5.A OS / Agent Log Growth (`/var/log`)

1. From the node debug session, identify the top consumers:
   ```bash
   du -xh --max-depth=2 /var/log 2>/dev/null | sort -h | tail -30
   journalctl --disk-usage
   ```
2. Rotate / vacuum systemd journal (safe, non-destructive):
   ```bash
   journalctl --rotate
   journalctl --vacuum-size=200M     # cap journal at 200 MiB
   journalctl --vacuum-time=2d       # or cap by age
   ```
3. Remove already-rotated, compressed logs older than N days (validate path first):
   ```bash
   find /var/log -type f \( -name '*.gz' -o -name '*.[0-9]' -o -name '*.[0-9].log' \) -mtime +7 -print
   # only after reviewing the list above:
   find /var/log -type f \( -name '*.gz' -o -name '*.[0-9]' -o -name '*.[0-9].log' \) -mtime +7 -delete
   ```
4. Do **not** delete the current active log file (e.g. `syslog`, `messages`, `kern.log`). Truncate only with the daemon's cooperation (`logrotate -f /etc/logrotate.conf`).
5. If a specific agent (e.g. logging, security) is the offender, raise a follow-up to tune its log level or rotation policy.

#### 5.B Container Image Bloat (`/var/lib/containerd`)

1. Inspect images and snapshot usage on the node:
   ```bash
   crictl images --digests
   ctr -n k8s.io images ls -q | wc -l
   du -xh --max-depth=1 /var/lib/containerd 2>/dev/null | sort -h | tail
   ```
2. Trigger the container runtime garbage collection by reducing pressure (preferred over manual deletion):
   - Kubelet image GC runs automatically when `imagefs` usage exceeds `--image-gc-high-threshold` (default 85%). If logs show `ImageGCFailed`, see **5.F**.
3. Manual prune of dangling / unused images (only after confirming with the Platform Lead, and never during a deployment window):
   ```bash
   crictl rmi --prune
   ```
4. Do **not** delete `/var/lib/containerd/io.containerd.snapshotter.*` contents manually — this will corrupt running containers.
5. If a small number of very large images dominate, raise a follow-up with the Application Owner to slim the image (multi-stage build, distroless base, remove dev tooling).

#### 5.C Pod Ephemeral / `emptyDir` Abuse

1. Identify the offending Pod(s) by size:
   ```bash
   du -xh --max-depth=3 /var/lib/kubelet/pods 2>/dev/null | sort -h | tail -20
   ```
   The path encodes the Pod UID; map it back to a Pod name:
   ```powershell
   kubectl get pods -A -o json |
     ConvertFrom-Json |
     Select-Object -ExpandProperty items |
     Where-Object { $_.metadata.uid -eq '<POD_UID>' } |
     Select-Object @{n='Namespace';e={$_.metadata.namespace}}, @{n='Pod';e={$_.metadata.name}}
   ```
2. Confirm whether the workload has an `ephemeral-storage` request/limit defined; if not, this is a known anti-pattern.
3. Short-term mitigation (with Application Owner approval):
   - Delete the offending Pod so the controller (Deployment / StatefulSet) recreates it on a healthy node:
     ```powershell
     kubectl delete pod <POD> -n <NAMESPACE>
     ```
   - For StatefulSets, ensure the underlying PVC is not affected (this is `emptyDir`, not a PVC, so deleting the Pod is safe for ephemeral data only — confirm the workload tolerates loss of `emptyDir`).
4. Long-term: open a follow-up to:
   - Add `ephemeral-storage` requests/limits to the workload.
   - Switch large scratch data from `emptyDir` to a PVC.
   - Configure log rotation inside the container or ship logs out via stdout + a logging agent.

#### 5.D PVC / PV Capacity Exhaustion

1. Confirm the PVC is the bottleneck:
   ```powershell
   kubectl get pvc -n <NAMESPACE>
   kubectl describe pvc <PVC> -n <NAMESPACE>
   ```
2. Inspect actual usage from inside the consuming Pod:
   ```powershell
   kubectl exec -it <POD> -n <NAMESPACE> -- df -h
   ```
3. If the StorageClass supports `allowVolumeExpansion: true`, expand the PVC:
   ```powershell
   kubectl patch pvc <PVC> -n <NAMESPACE> -p '{"spec":{"resources":{"requests":{"storage":"<NEW_SIZE>"}}}}'
   ```
   Some workloads (e.g. block volumes on certain CSI drivers) require a Pod restart to pick up the new size.
4. If expansion is not supported, engage the Storage Owner to migrate data to a larger volume; do **not** delete the PVC.
5. Long-term: review retention / archival policy with the Application Owner.

#### 5.E Inode Exhaustion

1. Confirm with `df -i` that an inode-heavy filesystem is at or near 100% used inodes.
2. Find directories with very large numbers of small files:
   ```bash
   for d in /var/log /var/lib/kubelet /var/lib/containerd /tmp; do
     echo "== $d =="
     find $d -xdev -type f 2>/dev/null | wc -l
   done
   ```
3. Apply the matching mitigation (5.A for logs, 5.B for images, 5.C for Pod scratch). Inode pressure cannot be relieved by truncation alone — files must be deleted or directories collapsed.

#### 5.F Image GC / Runtime Misconfiguration

1. Check kubelet events / logs for `ImageGCFailed` or `FreeDiskSpaceFailed`:
   ```powershell
   kubectl get events -A --field-selector involvedObject.name=<NODE> --sort-by=.lastTimestamp |
     Select-String -Pattern 'ImageGC|FreeDiskSpace'
   ```
2. On AKS, the kubelet `--image-gc-*` thresholds are managed via the node pool's kubelet config. Confirm current settings via the AKS API / portal; do **not** edit `/var/lib/kubelet/config.yaml` by hand on a managed node — it will be reverted by the AKS node image.
3. If thresholds are too aggressive (very small free buffer), open a change request to adjust the node pool's `kubeletConfig` (`imageGcHighThreshold`, `imageGcLowThreshold`) via `az aks nodepool update`.
4. Cordon and drain the affected node so AKS can replace it with a fresh OS image as a definitive reset:
   ```powershell
   kubectl cordon <NODE>
   kubectl drain <NODE> --ignore-daemonsets --delete-emptydir-data --timeout=10m
   az aks nodepool upgrade --node-image-only --cluster-name <AKS> --resource-group <RG> --name <NODE_POOL>
   ```

#### 5.G Node Pool Undersized

1. Confirm with Container Insights that multiple nodes in the same pool are sustained above 85% disk usage, with no single offender.
2. Options, in order of preference:
   - Increase OS disk size on the node pool (requires node replacement):
     ```powershell
     az aks nodepool update --cluster-name <AKS> --resource-group <RG> --name <NODE_POOL> --node-osdisk-size <NEW_SIZE_GB>
     ```
     **Note:** On AKS, changing OS disk size typically requires creating a new node pool and migrating workloads. Validate the procedure in a non-prod cluster first.
   - Add a new node pool with larger OS disks, cordon and drain old pool, then delete it.
   - Use ephemeral OS disks where appropriate (smaller, faster, but bound to the VM size's cache).
3. Approve as a change request (Change Manager) before executing in production.

#### 5.H Crash Artifacts

1. Look for core dumps and heap dumps:
   ```bash
   find / -xdev -type f \( -name 'core.*' -o -name 'hs_err_pid*.log' -o -name '*.hprof' \) -size +50M 2>/dev/null
   ls -lh /var/crash 2>/dev/null
   ```
2. Copy artifacts to durable storage (blob / file share) **before** deletion if the Application Owner needs them for diagnosis.
3. Delete with explicit paths, never with broad wildcards:
   ```bash
   rm -v /var/crash/core.<PID>.<TIMESTAMP>
   ```
4. Follow up with the Application Owner to configure a dedicated dump location (PVC) and a retention policy.

### Step 6 — Verify Recovery

Recovery is confirmed when **all** of the following hold for at least 15 minutes:

- `kubectl describe node <NODE>` shows `DiskPressure=False` and `Ready=True`.
- All target filesystems are below 80% used (`df -h`) and below 80% inodes (`df -i`).
- No new `EvictionThresholdMet`, `NodeHasDiskPressure`, `ImageGCFailed`, or `FreeDiskSpaceFailed` events for the node.
- Previously evicted Pods have been rescheduled and are `Running` / `Ready`.
- Application-level health endpoint and key business KPIs are within normal bounds.
- For PVC remediation: the consuming Pod reports the expanded size via `df -h` inside the container.

Record verification evidence (timestamps, `df` output, screenshot of Container Insights) in the ticket.

### Step 7 — Communicate & Close

1. Update the incident channel with the resolution summary:
   - Which filesystem and which directory was the root cause.
   - What action restored service (log vacuum, image prune, PVC expand, node replace, etc.).
   - Any residual risk or follow-ups (e.g. "image GC threshold needs tuning").
2. Close the incident in the ITSM tool with category and root-cause code populated.
3. Notify the Application Owner and downstream stakeholders.

### Step 8 — Post-Incident Review

Required for Sev-1 and recommended for Sev-2:

- Schedule a blameless review within 5 business days.
- Capture timeline, contributing factors, and corrective actions.
- File backlog items for permanent fixes, e.g.:
  - Add `ephemeral-storage` requests/limits to all workloads.
  - Tune kubelet image GC thresholds for the node pool.
  - Add alerts at 70% / 80% disk usage in addition to the existing 85% threshold.
  - Slim oversized container images.
  - Enable automatic PVC expansion or move to a larger StorageClass.
- Update this SOP if a new failure mode or mitigation was discovered.

## 8. Escalation Matrix

| Condition                                                            | Escalate to             | Within  |
| -------------------------------------------------------------------- | ----------------------- | ------- |
| Recovery not achieved within 30 minutes                              | Platform / SRE Lead     | 30 min  |
| Customer-facing workload still degraded after 1 hour                 | Incident Manager (Sev-1)| 60 min  |
| Suspected data loss (truncated logs needed for audit, deleted dumps) | Data Owner + Security   | Immediately |
| Suspected control-plane / etcd disk issue on managed AKS             | Azure Support           | Immediately |
| Multiple node pools or whole cluster under disk pressure             | AKS Cluster Outage SOP  | Immediately |
| Storage backend (managed disk / file share) error or corruption      | Storage Owner           | Immediately |

## 9. Useful Reference Commands

```powershell
# Watch node conditions
kubectl get nodes -w

# Top pods by ephemeral-storage requests (best-effort; not all clusters expose usage)
kubectl get pods -A -o json |
  ConvertFrom-Json |
  Select-Object -ExpandProperty items |
  ForEach-Object {
    $req = $_.spec.containers | ForEach-Object { $_.resources.requests.'ephemeral-storage' } | Where-Object { $_ }
    if ($req) {
      [pscustomobject]@{
        Namespace = $_.metadata.namespace
        Pod       = $_.metadata.name
        EphReq    = ($req -join ',')
      }
    }
  } | Sort-Object EphReq -Descending | Select-Object -First 20

# Drain a node safely
kubectl cordon <NODE>
kubectl drain <NODE> --ignore-daemonsets --delete-emptydir-data --timeout=10m

# Replace an AKS node by upgrading only the node image
az aks nodepool upgrade --node-image-only --cluster-name <AKS> --resource-group <RG> --name <NODE_POOL>

# Expand a PVC (StorageClass must allow volume expansion)
kubectl patch pvc <PVC> -n <NAMESPACE> -p '{"spec":{"resources":{"requests":{"storage":"<NEW_SIZE>"}}}}'

# Open a privileged shell on a node (no SSH needed)
kubectl debug node/<NODE> -it --image=mcr.microsoft.com/cbl-mariner/busybox:2.0
```

## 10. Safety Notes (Read Before Cleanup)

- Never run `rm -rf` against `/`, `/var`, `/var/lib`, `/var/lib/kubelet`, or `/var/lib/containerd`.
- Never truncate or delete active log files for compliance-relevant components (audit, security agents) without Security approval.
- Never delete `containerd` snapshots or overlay layers manually — use `crictl rmi --prune` only.
- Prefer node replacement (cordon + drain + node-image upgrade) over in-place surgery on managed AKS nodes — the AKS node image is the source of truth.
- Capture core dumps / heap dumps to durable storage before deleting them; they are often the only evidence of the underlying crash.
- Get Application Owner approval before evicting or deleting Pods that may hold in-memory state.

## 11. Related Documents

- Pod Unhealthy / CrashLoopBackOff SOP (SOP-K8S-001)
- AKS Cluster Outage SOP
- Storage / PVC Recovery SOP
- Secrets and Key Vault SOP
- Incident Management Policy
- Logging and Retention Policy

## 12. Revision History

| Version | Date       | Author | Change Summary           |
| ------- | ---------- | ------ | ------------------------ |
| 1.0     | YYYY-MM-DD | TBD    | Initial template version |
