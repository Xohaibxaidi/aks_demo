# Lab 2

## Identify pods in a namespace, inspect status and events

kubectl get pods -n default
kubectl get pods -A
kubectl get deploy –A
kubectl get events --sort-by=.metadata.creationTimestamp

## Check logs for a failing pod and extract key error information

kubectl apply -f failing-pod.yaml
kubectl get pods
kubectl describe pod nginx-pod
kubectl delete pod nginx-pod

kubectl apply -f fixed-pod.yaml
kubectl get pods
kubectl describe pod nginx-pod
kubectl delete pod nginx-pod

## Map deployment → pods → node

kubectl apply -f sample-dep.yaml
kubectl describe deployment sample-dep
kubectl get pods --selector="$(kubectl get deployment sample-dep -o jsonpath='{.spec.selector.matchLabels}' | jq -r 'to_entries|map("\(.key)=\(.value)")|join(",")')" -o wide
kubectl delete deployment sample-dep