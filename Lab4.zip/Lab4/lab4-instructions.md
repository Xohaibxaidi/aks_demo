# Lab 4

## Introduced scenario: a pod's log/temp folder fills the disk

A common production incident: an app writes logs or temp files unbounded until the pod's ephemeral storage (or an `emptyDir` volume) is exhausted. The kubelet then evicts the pod with `Evicted` / `DiskPressure`, or the pod starts failing writes.

The `disk-filler` deployment in this lab simulates that by writing ~1.5MB/sec into `/var/log/app` and `/tmp/app`. Each volume has a 50Mi `sizeLimit` and the container has a 100Mi ephemeral-storage limit, so eviction happens within ~1 minute.

### Deploy the misbehaving workload

kubectl apply -f disk-filler.yaml
kubectl rollout status deployment/disk-filler
kubectl get pods -l app=disk-filler -w

### Identify via events and pod status

kubectl get pods -l app=disk-filler
kubectl describe pod -l app=disk-filler
kubectl get events --sort-by=.lastTimestamp | Select-String -Pattern "disk-filler|Evicted|DiskPressure|Ephemeral"

### Exec into the pod and find the large files

POD=$(kubectl get pod -l app=disk-filler -o jsonpath='{.items[0].metadata.name}')

#### Check mounted filesystem usage

kubectl exec -it $POD -- sh -c "df -h /var/log/app /tmp/app"

#### Summarize directory disk usage

kubectl exec -it $POD -- sh -c "du -sh /var/log/app /tmp/app"

##### List largest log files

kubectl exec -it $POD -- sh -c "ls -lhS /var/log/app | head -20"

#### List largest temp files

kubectl exec -it $POD -- sh -c "ls -lhS /tmp/app | head -20"

#### Find biggest files over 1MB

kubectl exec -it $POD -- sh -c "find /var/log/app /tmp/app -type f -size +1M -printf '%s %p\n' | sort -nr | head"

### Clean up the offending files in-place

kubectl exec -it $POD -- sh -c "rm -f /var/log/app/*.log /tmp/app/*.dat"
kubectl exec -it $POD -- sh -c "df -h /var/log/app /tmp/app"

> Note: cleanup buys time but the app will refill the volume. The real fix is log rotation, a sidecar shipper, or bounded volume usage.

### Reboot the pod and confirm it returns healthy

kubectl delete pod -l app=disk-filler
# or, for a rolling restart of the whole deployment:
kubectl rollout restart deployment/disk-filler
kubectl rollout status deployment/disk-filler
kubectl get pods -l app=disk-filler

### Apply a fix (log rotation / bounded storage)

Edit `disk-filler.yaml` to:

- Increase `emptyDir.sizeLimit` and `resources.limits.ephemeral-storage`, OR
- Add a sidecar that rotates/truncates logs, OR
- Mount a dedicated PVC for `/var/log/app` so writes don't consume node ephemeral storage.

kubectl apply -f disk-filler.yaml
kubectl rollout status deployment/disk-filler
kubectl get pods -l app=disk-filler

### Cleanup

kubectl delete -f disk-filler.yaml
