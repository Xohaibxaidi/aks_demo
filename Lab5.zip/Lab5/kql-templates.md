# KQL Templates for Lab 5

Replace the placeholder values before running each query.

## Template 1: Repeated restarts

Use this to find pods and containers with the highest restart counts during the investigation window.

```kusto
let lookback = 1h;
let targetNamespace = "production";
let targetController = "member-portal";
KubePodInventory
| where TimeGenerated >= ago(lookback)
| where Namespace == targetNamespace
| where ControllerName startswith targetController or Name startswith targetController
| summarize RestartCount=max(ContainerRestartCount) by bin(TimeGenerated, 5m), Namespace, ControllerName, PodName=Name, ContainerName
| order by RestartCount desc, TimeGenerated desc
```

If you want the worst offenders only:

```kusto
let lookback = 1h;
let targetNamespace = "production";
let targetController = "member-portal";
KubePodInventory
| where TimeGenerated >= ago(lookback)
| where Namespace == targetNamespace
| where ControllerName startswith targetController or Name startswith targetController
| summarize PeakRestartCount=max(ContainerRestartCount) by Namespace, ControllerName, PodName=Name, ContainerName, Computer
| order by PeakRestartCount desc
```

## Template 2: Error or exception peaks

Use this to find bursts of application failures in container logs.

```kusto
let lookback = 1h;
let targetNamespace = "production";
let podPrefix = "member-portal";
ContainerLogV2
| where TimeGenerated >= ago(lookback)
| where KubernetesMetadata.Namespace == targetNamespace
| where PodName startswith podPrefix
| where LogMessage has_any ("error", "exception", "fail", "fatal", "timeout")
| summarize ErrorEvents=count() by bin(TimeGenerated, 5m), PodName, ContainerName
| order by TimeGenerated asc
```

If `ContainerLogV2` is not enabled in the workspace, use the legacy table:

```kusto
let lookback = 1h;
let targetNamespace = "production";
let podPrefix = "member-portal";
ContainerLog
| where TimeGenerated >= ago(lookback)
| where Name startswith podPrefix
| where LogEntry has_any ("error", "exception", "fail", "fatal", "timeout")
| summarize ErrorEvents=count() by bin(TimeGenerated, 5m), Name, ContainerID
| order by TimeGenerated asc
```

## Optional correlation query: CPU plus restart signal

Use this when you want one view that highlights busy pods together with restart activity.

```kusto
let lookback = 1h;
let targetNamespace = "production";
let podPrefix = "member-portal";
let restartData =
    KubePodInventory
    | where TimeGenerated >= ago(lookback)
    | where Namespace == targetNamespace
    | where Name startswith podPrefix
    | summarize RestartCount=max(ContainerRestartCount) by bin(TimeGenerated, 5m), PodName=Name;
let cpuData =
    InsightsMetrics
    | where TimeGenerated >= ago(lookback)
    | where Namespace == "container.azm.ms/pod"
    | where Name == "cpuUsageNanoCores"
    | extend PodName=tostring(Tags.podName), KubernetesNamespace=tostring(Tags.k8sNamespace)
    | where KubernetesNamespace == targetNamespace
    | where PodName startswith podPrefix
    | summarize AvgCpuNanoCores=avg(Val) by bin(TimeGenerated, 5m), PodName;
cpuData
| join kind=leftouter restartData on TimeGenerated, PodName
| order by TimeGenerated asc
```
