# Lab 5

## Introduced scenario: CPU spikes on member-portal pods

This lab shifts from node-local troubleshooting to Azure-based investigation. You are given an incident description such as "CPU spikes on member-portal pods" and need to determine whether the issue is isolated to one pod, one replica set, or a broader workload pattern.

This lab assumes the AKS cluster is already connected to Azure Monitor, Container Insights, and a Log Analytics workspace.

### Open AKS Insights and scope the investigation

1. Open the target AKS cluster in the Azure portal.
2. Go to `Insights`.
3. Set the time range to the last 30 minutes or 1 hour.
4. Start on the `Nodes` tab to check whether the spike is node-wide or localized.
5. Move to the `Workloads` or `Controllers` view and filter to the namespace that hosts `member-portal`.

### Identify whether the issue is node pressure or noisy pods

Use the charts to answer the following:

- Are CPU and memory spikes visible on one node or across multiple nodes?
- Is `member-portal` consistently above its peers?
- Is one pod replica consuming much more CPU than the others?
- Is memory growth accompanying the CPU increase?

Record the answers before moving on.

### Drill into the noisy pod instances

1. In `Insights`, open the pod or controller view for `member-portal`.
2. Sort by CPU usage.
3. Note the pod names with the highest CPU.
4. Check whether the same pods also show high memory usage or recent restarts.
5. Capture the namespace, pod name, node name, and approximate spike window.

### Correlate with Kubernetes state

Use `kubectl` to validate what you saw in the portal.

kubectl get pods -A -o wide
kubectl top pods -A --sort-by=cpu
kubectl top nodes

If the noisy workload is isolated to one namespace, narrow the check further:

kubectl get pods -n NAMESPACE -o wide
kubectl top pods -n NAMESPACE --sort-by=cpu
kubectl describe pod POD_NAME -n NAMESPACE

### Write down the first conclusion

At this point you should be able to state whether the incident is caused by:

- One or two noisy pod replicas
- A deployment-wide increase in load
- A node-level saturation event affecting multiple workloads

## Introduced scenario: repeated restarts and error peaks

After identifying the hottest pods, use Log Analytics queries to determine whether the CPU event coincides with instability or application faults.

### Open the provided KQL templates

Use the queries in `kql-templates.md` from this folder.

1. In the Azure portal, from the AKS cluster or connected Log Analytics workspace, open `Logs`.
2. Copy the required query from `kql-templates.md`.
3. Replace the placeholder values for namespace, controller, pod prefix, and time range.

### Query for repeated restarts

Run the restart template first.

Look for:

- Pods with restart counts increasing during the incident window
- One container restarting more often than its peers
- Restarts concentrated on a single node or replica

### Query for error and exception peaks

Run the error peak template next.

Look for:

- Bursts of `error`, `exception`, `fail`, `fatal`, or `timeout` messages
- Time alignment between log spikes and the CPU spike window
- A single pod producing most of the failures

### Form the incident summary

Write a short incident statement that includes:

- The affected workload and namespace
- The noisy pods, if any
- Whether restart activity increased
- Whether log errors peaked at the same time
- Your best current hypothesis for the cause

Example:

> Between 10:20 and 10:35, `member-portal` in namespace `production` showed elevated CPU on two replicas, with one pod accounting for most of the spike. Restart counts increased on the same replica during that period, and application logs showed a matching peak in timeout and exception messages.

### Cleanup

No cluster-side cleanup is required for this lab. Close any saved queries or workbook views if needed.
